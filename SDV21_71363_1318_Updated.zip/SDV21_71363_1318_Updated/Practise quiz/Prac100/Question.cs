﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prac100
{
    public class Question
    {
        public string questionText { get; set; }
        public string[] answers { get; set; }
        public int correctAnsPosition { get; set; }

        public Question(String quText, String[] answers, int correctAnsPosition)
        {
            this.questionText = quText;
            this.answers = answers;
            this.correctAnsPosition = correctAnsPosition;
        }
    }
}
