﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prac100
{
    public class CodeQuiz : Quiz

    {
        public CodeQuiz(Player player, int time) : base(player)
        {
            addQuestions();
            setTimeOfQuiz(time);
        }
        public override void setTimeOfQuiz(int time)
        {
            countDown = time;
        }
        public override void addQuestions()
        {
            questions.Add(new Question("What is the sign for modulus",
                new[] { "+", "%", "-", "*" }, 1));
            questions.Add(new Question("Which loop repeats a finite number of times?",
                new[] { "for", "while", "do", "forevery" }, 0));

        }


    }
}
   
    

