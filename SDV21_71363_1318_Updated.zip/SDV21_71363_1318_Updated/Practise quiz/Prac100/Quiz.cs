﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prac100
{
    public class Quiz
    {
        public Player player { get; set; }
        public int countDown { get; set; }
        public List<Question> questions = new List<Question>();
        public int currentQuPosition { get; set; }

        public Quiz(Player player)
        {
            this.player = player;
            this.currentQuPosition = 0;
        }
        public virtual void setTimeOfQuiz(int time)
        {
        }
        public virtual void addQuestions()
        {
        }
        public Boolean hasNextQuestion
        {
          get {return currentQuPosition<(questions.Count - 1); }
        }  
        public void checkAnswer(int selectedIndex)
        {
            if (selectedIndex == questions[currentQuPosition].correctAnsPosition)
            {
                player.score++;

            }
        }
        public void resetQuiz()
        {
            currentQuPosition = 0;
            player.score = 0;
        }
    }
}
