﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prac100
{
    public partial class GameScreen : Form
    {
        private Timer _timer = new Timer();
        public GameScreen(string name, int quizNum)
        {
            InitializeComponent();
            CenterToScreen();
            setupQuiz(name, quizNum);
        }

        private void setupQuiz(String name, int quizNum)
        {
            Player player = new Player(name);
            Text = player.name + @"'s Quiz";
            switch(quizNum)
            {
                case 1:
                    StartQuiz._quiz = new CodeQuiz(player, 15);
                    firstQuestion();
                    setupTimer();
                    _timer.Start();
                    break;
                case 2:
                    StartQuiz._quiz = new ICTQuiz(player, 20);
                    firstQuestion();
                    setupTimer();
                    _timer.Start();       
                    break;
                        

                        
            }    

        }

        private void GameScreen_Load(object sender, EventArgs e)
        {
           
        }
        private void firstQuestion()
        {
            quTextLabel.Text = StartQuiz._quiz.questions.First().answers[0];
            quLabel.Text = "Question " + (StartQuiz._quiz.currentQuPosition + 1);

            ans1Btn.Text = StartQuiz._quiz.questions.First().answers[0];
            ans2Btn.Text =  StartQuiz._quiz.questions.First().answers[1];
            ans3Btn.Text = StartQuiz._quiz.questions.First().answers[2];
            ans4Btn.Text =  StartQuiz._quiz.questions.First().answers[3];
        }
        private void ans1Btn_Click(object sender, EventArgs e)
        {
            StartQuiz._quiz.checkAnswer(0);
            nextQuestion();
        }
        private void ans2Btn_Click(object sender, EventArgs e)
        {
            StartQuiz._quiz.checkAnswer(1);
            nextQuestion();
        }
        private void ans3Btn_Click(object sender, EventArgs e)
        {
            StartQuiz._quiz.checkAnswer(2);
            nextQuestion();
        }
        private void ans4Btn_Click(object sender, EventArgs e)
        {
            StartQuiz._quiz.checkAnswer(3);
            nextQuestion();
        }
    }
}
