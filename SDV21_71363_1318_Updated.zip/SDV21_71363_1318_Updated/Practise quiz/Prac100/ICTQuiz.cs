﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prac100
{
    public class ICTQuiz : Quiz

    {
        public ICTQuiz(Player player, int time) : base(player)
        {
            addQuestions();
            setTimeOfQuiz(time);
        }
        public override void setTimeOfQuiz(int time)
        {
            countDown = time;
        }
        public override void addQuestions()
        {
            questions.Add(new Question("How many bits are in a byte",
                new[] { "8", "6", "2", "4" },0));
            questions.Add(new Question("What is the storage size on a standard DVD",
                new[] { "1.44Gb", "4.56Gb", "5.2Gb", "4.7Gb" }, 3));

        }


    }
}
