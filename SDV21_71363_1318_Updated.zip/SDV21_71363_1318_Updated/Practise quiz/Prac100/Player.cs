﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prac100
{
    public class Player
    {
        public String name { get; set; }
        public int score { get; set; }

        public Player(String name)
        {
            this.name = name;
            this.score = 0;

        }
    }
}
