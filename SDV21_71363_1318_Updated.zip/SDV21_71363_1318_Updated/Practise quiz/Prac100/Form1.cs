﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Prac100
{
    public partial class StartQuiz : Form
    {
        public static Quiz _quiz;
        public StartQuiz()
        {
            InitializeComponent();
            CenterToScreen();
            populateNameFromPrevious();
            getLastScore();

        }

        private void populateNameFromPrevious()
        {



            if (_quiz != null)
            {
                if (_quiz.player.name.Any())
                {
                    userName.Text = _quiz.player.name;
                }
            }
        }
      public partial class Form1 : Form
      {
            public static Quiz _quiz;
      }
        public void getLastScore()
        {
            try
            {
                BinaryReader bContent = new BinaryReader(
                File.Open("c:\\ Users \\ user \\ Desktop\\ scores.bin", FileMode.Open));
                int pos = 0;
                int length = (int)bContent.BaseStream.Length;
                while (pos < length)
                {
                    int score = bContent.ReadInt32();
                    prevScoreLbl.Text += " " + score;
                    prevScoreLbl.Visible = true;
                    pos += sizeof(int);

                }
                bContent.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine("General Exception " + ex);
                prevScoreLbl.Visible = false;
            }

        }
            private void codeQuizBtn_Click(object sender, EventArgs e)
            {
                StartQuiz(1);
            }

            private void ictQuizBtn_Click(object sender, EventArgs e)
            {
                StartQuiz(2);
            }
        private void startQuiz(int quizNum)
        {
            if (userName.Text.Any())
            {
                GameScreen gameScreen = new GameScreen(userName.Text, quizNum);
                gameScreen.Show();
                Hide();
            }
            else
            {
                MessageBox.Show("Please Enter yupr name", "player name missing");
            }
        }

    }
}

