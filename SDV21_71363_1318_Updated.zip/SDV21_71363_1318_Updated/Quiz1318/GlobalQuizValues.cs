﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quiz1318
{
    class GlobalQuizValues
    {
        public static int playerScoreDuringQuiz;
        public static int numberOfGamesPlayed;
    }
}
