﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz1318
{
    public partial class frmQuestion1 : Form
    {
        int score = 0;

                public string[] questions = {
                "What is the capital of France?",
                "Which country is known as the Land of the Rising Sun?",
                "What is the largest desert in the world?",
                "Which river is the longest in the world?",
                "In which continent is the Amazon Rainforest located?",
                "What is the currency of Japan?",
                "Which mountain is the tallest in the world?",
                "Which country is famous for the Great Barrier Reef?",
                "What is the official language of Brazil?",
                "In which country is the ancient city of Rome located?"
                };

                public string[] answers = {
                "paris", "japan", "antarctica", "nile", "south america",
                "yen", "mount everest", "australia", "portuguese", "italy"
                };
            
        public frmQuestion1()
        {
            InitializeComponent();

            int score = 0;

            for (int i = 1; i <= 10; i++)
            {
                

                // Display final score
                Console.WriteLine($"\nYour final score: {score} out of 10");

                int randomIndex = new Random().Next(0, questions.Length);
                string currentQuestion = questions[randomIndex];
                questionLbl.Text = currentQuestion;
            }
        }
        
        public void button1_Click(object sender, EventArgs e)
        {
            for (int i = 1; i <= 10; i++)
            {
                int randomIndex = new Random().Next(0, questions.Length);
                string currentQuestion = questions[randomIndex];
                string userAnswer = textBox1.Text.ToLower();


                if (userAnswer == answers[randomIndex])
                {
                    MessageBox.Show("Correct!");
                    score++;
                }
                else
                {
                    MessageBox.Show($"Incorrect. The correct answer is {answers[randomIndex]}.");
                }
            }
        }
    }
}
