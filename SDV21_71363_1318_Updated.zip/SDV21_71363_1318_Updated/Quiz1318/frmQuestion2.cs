﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz1318
{
    public partial class Question2 : Form
    {
        GlobalQuizValues values = new GlobalQuizValues();

        

        public Question2()
        {
            InitializeComponent();
        }

        bool quesAns1, quesAns2, quesAns3, quesAns4, quesAns5, quesAns6, quesAns7, quesAns8, quesAns9, quesAns10 = false;

        private void timer1_Tick(object sender, EventArgs e)
        {
            int _counter = 0;
            Timer timer;

            timer = new Timer();
            timer.Interval = 60000;
            timer.Tick += new EventHandler(TimerEventProcessor);
            label1.Text = _counter.ToString();
            timer.Start();

             void TimerEventProcessor(object sender, EventArgs e)
            {
                label14.Text = _counter.ToString();
                _counter += 1;
            } 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            quesAns1 = true;
            button1.Enabled = false;
            button11.Enabled = false;
            button1.BackColor = Color.Green;
            button11.BackColor = Color.Red;

        }
        private void button12_Click(object sender, EventArgs e)
        {
            quesAns2 = false;
            button12.Enabled = false;
            button12.BackColor = Color.Green;
            button2.BackColor = Color.Red;
        }
    }
}
