﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz1318
{
    public partial class Splashscreen : Form
    {

        public Splashscreen()
        {
            InitializeComponent();
        }

        private void Main(object sender, EventArgs e)
        {

        }
         private void tmrSplash_Tick(object sender,EventArgs e)
        {
           
            //This timer is set to 3 seconds

            tmrSplash.Stop();
            this.Close();
        }

    }
}
