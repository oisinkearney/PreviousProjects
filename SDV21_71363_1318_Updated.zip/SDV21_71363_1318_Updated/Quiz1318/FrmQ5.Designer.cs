﻿
namespace Quiz1318
{
    partial class FrmQ5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQ5));
            this.label1 = new System.Windows.Forms.Label();
            this.pctQ5Answer1 = new System.Windows.Forms.PictureBox();
            this.pctQ5Answer2 = new System.Windows.Forms.PictureBox();
            this.pctQ5Answer3 = new System.Windows.Forms.PictureBox();
            this.pctQ5Answer4 = new System.Windows.Forms.PictureBox();
            this.lblAnswer = new System.Windows.Forms.Label();
            this.lblCurrentPlayerScore = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pctQ5Answer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctQ5Answer2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctQ5Answer3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctQ5Answer4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(63, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(229, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Drag the continent to corresponding box";
            // 
            // pctQ5Answer1
            // 
            this.pctQ5Answer1.Location = new System.Drawing.Point(12, 64);
            this.pctQ5Answer1.Name = "pctQ5Answer1";
            this.pctQ5Answer1.Size = new System.Drawing.Size(100, 67);
            this.pctQ5Answer1.TabIndex = 1;
            this.pctQ5Answer1.TabStop = false;
            // 
            // pctQ5Answer2
            // 
            this.pctQ5Answer2.Location = new System.Drawing.Point(12, 158);
            this.pctQ5Answer2.Name = "pctQ5Answer2";
            this.pctQ5Answer2.Size = new System.Drawing.Size(100, 67);
            this.pctQ5Answer2.TabIndex = 2;
            this.pctQ5Answer2.TabStop = false;
            // 
            // pctQ5Answer3
            // 
            this.pctQ5Answer3.Location = new System.Drawing.Point(12, 251);
            this.pctQ5Answer3.Name = "pctQ5Answer3";
            this.pctQ5Answer3.Size = new System.Drawing.Size(100, 67);
            this.pctQ5Answer3.TabIndex = 3;
            this.pctQ5Answer3.TabStop = false;
            // 
            // pctQ5Answer4
            // 
            this.pctQ5Answer4.Location = new System.Drawing.Point(12, 338);
            this.pctQ5Answer4.Name = "pctQ5Answer4";
            this.pctQ5Answer4.Size = new System.Drawing.Size(100, 67);
            this.pctQ5Answer4.TabIndex = 4;
            this.pctQ5Answer4.TabStop = false;
            // 
            // lblAnswer
            // 
            this.lblAnswer.AutoSize = true;
            this.lblAnswer.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAnswer.Location = new System.Drawing.Point(197, 228);
            this.lblAnswer.Name = "lblAnswer";
            this.lblAnswer.Size = new System.Drawing.Size(49, 20);
            this.lblAnswer.TabIndex = 5;
            this.lblAnswer.Text = "Answer";
            // 
            // lblCurrentPlayerScore
            // 
            this.lblCurrentPlayerScore.AutoSize = true;
            this.lblCurrentPlayerScore.Location = new System.Drawing.Point(20, 437);
            this.lblCurrentPlayerScore.Name = "lblCurrentPlayerScore";
            this.lblCurrentPlayerScore.Size = new System.Drawing.Size(47, 15);
            this.lblCurrentPlayerScore.TabIndex = 6;
            this.lblCurrentPlayerScore.Text = "Current";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.pictureBox1.Location = new System.Drawing.Point(175, 251);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 67);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(269, 338);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(61, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 8;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(336, 338);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(61, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(319, 426);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 23);
            this.button1.TabIndex = 10;
            this.button1.Text = "Check Answer";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // FrmQ5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 461);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblCurrentPlayerScore);
            this.Controls.Add(this.lblAnswer);
            this.Controls.Add(this.pctQ5Answer4);
            this.Controls.Add(this.pctQ5Answer3);
            this.Controls.Add(this.pctQ5Answer2);
            this.Controls.Add(this.pctQ5Answer1);
            this.Controls.Add(this.label1);
            this.Name = "FrmQ5";
            this.Text = "FrmQ5";
            ((System.ComponentModel.ISupportInitialize)(this.pctQ5Answer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctQ5Answer2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctQ5Answer3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctQ5Answer4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pctQ5Answer1;
        private System.Windows.Forms.PictureBox pctQ5Answer2;
        private System.Windows.Forms.PictureBox pctQ5Answer3;
        private System.Windows.Forms.PictureBox pctQ5Answer4;
        private System.Windows.Forms.Label lblAnswer;
        private System.Windows.Forms.Label lblCurrentPlayerScore;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button button1;
    }
}