﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz1318
{
    public partial class FrmQuestion3 : Form
    {
        int score;
        public FrmQuestion3()
        {
            InitializeComponent();

        }




        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("correct Answer");
            score++;
        }


        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");
        }
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");
        }
        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("correct Answer");
            score++;
        }
        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");
        }
        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");
        }
        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");
        }
        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");
        }
        private void radioButton10_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");

        }
        private void radioButton11_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("correct Answer");
            score++;
        }
        private void radioButton12_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");

        }

        private void radioButton13_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("correct Answer");
            score++;
        }
        private void radioButton14_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");

        }
        private void radioButton15_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");

        }
        private void radioButton16_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");


        }
        private void radioButton17_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("correct Answer");
            score++;
        }
        private void radioButton18_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");


        }
        private void radioButton19_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");


        }
        private void radioButton20_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");


        }
        private void radioButton21_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");


        }
        private void radioButton22_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");

        }
        private void radioButton24_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Incorrect Answer");

        }
        private void radioButton23_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("correct Answer");
            score++;
        }
    }
}