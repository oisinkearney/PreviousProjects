﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Quiz1318
{
    public partial class frmPlayerSelectionNew : Form
    {
        int arrPlayerIcons = 0;
        List<PlayerDetails> players = new List<PlayerDetails>();
        List<string> errors = new List<String>();

        public frmPlayerSelectionNew()
        {
            InitializeComponent();

        }
        private void frmPlayerSelectionNew_Load(object sender, EventArgs e)
        {
            pctPlayerIcon1.AllowDrop = true;
            pctPlayerIcon2.AllowDrop = true;
            pctPlayerIcon3.AllowDrop = true;
            pctPlayerIconChoosen.AllowDrop = true;


            this.ActiveControl = txtPlayerName;
            if (File.Exists("PlayerObjects.bin"))
            {
                players = ReadFromFile(players);
            }
        }

        public static List<PlayerDetails> ReadFromFile(List<PlayerDetails> playerlist)
        {
            Stream sr;
            BinaryFormatter bf = new BinaryFormatter();
            
            try
            {
                sr = File.OpenRead("PlayerObjects.bin");
                playerlist = (List<PlayerDetails>)bf.Deserialize(sr);
                sr.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("" + e.Message);
            }
            return playerlist;
        }

        private void pctPlayerIcon1_MouseDown(object sender, MouseEventArgs e)
        {
            pctPlayerIcon1.DoDragDrop(pctPlayerIcon1.Image, DragDropEffects.Copy);
            arrPlayerIcons = 1;
            // yes
        }

        private void pctPlayerIcon2_MouseDown(object sender, MouseEventArgs e)
        {
            pctPlayerIcon2.DoDragDrop(pctPlayerIcon2.Image, DragDropEffects.Copy);
            arrPlayerIcons = 2;
            //yes

        }
        private void pctPlayerIcon3_MouseDown(object sender, MouseEventArgs e)
        {
            pctPlayerIcon3.DoDragDrop(pctPlayerIcon3.Image, DragDropEffects.Copy);
            arrPlayerIcons = 3;
            //yes
        }

        private void pctPlayerIconChoosen_DragDrop(object sender, DragEventArgs e)
        {
            pctPlayerIconChoosen.Image = (Image)e.Data.GetData(DataFormats.Bitmap);
            //yes
        }


        private void pctPlayerIconChoosen_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
            lblDateOfQuiz.Text = DateTime.Now.ToShortDateString();
        }
        public static void WriteToFile(List<PlayerDetails> playerlist)

        {
            Stream sw;
            BinaryFormatter bf = new BinaryFormatter();

            try
            {
                sw = File.Open("PlayerObjects.bin", FileMode.Create);
                bf.Serialize(sw, playerlist);
                sw.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("" + e.Message);
            }
        }
        private void btnNextScreenRules_Click(object sender, EventArgs e)
        {
            PlayerDetails newRegistration = new PlayerDetails();

            if (players.Count > 0)
            {
                foreach (PlayerDetails current in players)
                {
                    if (current.PlayerName == txtPlayerName.Text)
                    {
                        errors.Add("Username already exists");
                    }
                }
            }

            try
            {
                newRegistration.PlayerName = txtPlayerName.Text;
            }
            catch (Exception ex)
            {
                errors.Add(ex.Message);
            }
            try
            {
                newRegistration.PlayerPassword = txtPlayerPassword.Text;
            }
            catch (Exception ex)
            {
                errors.Add(ex.Message);
            }

            if (errors.Count == 0)
            {
                //change to frmLogin if all succesful
                players.Add(newRegistration);
                WriteToFile(players);

                this.Hide();
                frmPlayerLogin frmLogin = new frmPlayerLogin();
                frmLogin.Show();
            }
            else
            {
                string errorMessage = string.Join("\n", errors.ToArray());
                MessageBox.Show(string.Format("Errors Encountered -" + "\n" + errorMessage));
                errors.Clear();
            }
        }
    }
}