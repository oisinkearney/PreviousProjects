﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz1318
{
    public partial class frmQ5n5 : Form
    {
        public frmQ5n5()
        {
            InitializeComponent();
        }
    }
}
