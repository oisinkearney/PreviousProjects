﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Quiz1318
{
    [Serializable]
    public class PlayerDetails
    {
        private string quizNumber;
        private string playerName;
        private string playerPassword;
        private int playerIcon;
        private int playerScore;
        private DateTime quizDate;

        public string Quiznumber
        {
            get { return quizNumber; }
            set { quizNumber = value; }
        }
        public string PlayerName
        {
            get { return playerName; }
            set { playerName = value; }
        }
            public string PlayerPassword
        {
            get { return playerPassword; }
            set { playerPassword = value; }
        }
        public int PlayerIcon
        {
            get { return playerIcon; }
            set { playerIcon = value; }
        }
        public int PlayerScore
        {
            get { return playerScore; }
            set { playerScore = value; }
        }
        public DateTime QuizDate
        {
            get { return quizDate; }
            set { quizDate = value; }
        }
        public PlayerDetails(string playername, string playerpass, int playericon, int playerscore, DateTime quizdate)
        {
            playerName = playername;
            playerPassword = playerpass;
            playerIcon = playericon;
            PlayerScore = playerscore;
            quizDate = quizdate;
        }
        public PlayerDetails()
        {

        }

    }
}
