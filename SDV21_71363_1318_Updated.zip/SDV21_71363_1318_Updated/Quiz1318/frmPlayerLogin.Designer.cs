﻿
namespace Quiz1318
{
    partial class frmPlayerLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblInstructionA = new System.Windows.Forms.Label();
            this.lblInstructionB = new System.Windows.Forms.Label();
            this.lblExistingUser = new System.Windows.Forms.Label();
            this.lblExistingUserName = new System.Windows.Forms.Label();
            this.lblExistingPassword = new System.Windows.Forms.Label();
            this.txtExistingUserName = new System.Windows.Forms.TextBox();
            this.txtExistingPassword = new System.Windows.Forms.TextBox();
            this.lblUserNotFound = new System.Windows.Forms.Label();
            this.btnLogOn = new System.Windows.Forms.Button();
            this.lblNewUsers = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblInstructionA
            // 
            this.lblInstructionA.AutoSize = true;
            this.lblInstructionA.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblInstructionA.Location = new System.Drawing.Point(75, 12);
            this.lblInstructionA.Name = "lblInstructionA";
            this.lblInstructionA.Size = new System.Drawing.Size(331, 29);
            this.lblInstructionA.TabIndex = 0;
            this.lblInstructionA.Text = "Please enter an existing user details ";
            // 
            // lblInstructionB
            // 
            this.lblInstructionB.AutoSize = true;
            this.lblInstructionB.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblInstructionB.Location = new System.Drawing.Point(94, 41);
            this.lblInstructionB.Name = "lblInstructionB";
            this.lblInstructionB.Size = new System.Drawing.Size(303, 29);
            this.lblInstructionB.TabIndex = 1;
            this.lblInstructionB.Text = "Or click to register as a new user.";
            // 
            // lblExistingUser
            // 
            this.lblExistingUser.AutoSize = true;
            this.lblExistingUser.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblExistingUser.Location = new System.Drawing.Point(153, 110);
            this.lblExistingUser.Name = "lblExistingUser";
            this.lblExistingUser.Size = new System.Drawing.Size(143, 29);
            this.lblExistingUser.TabIndex = 2;
            this.lblExistingUser.Text = "Existing Users:";
            // 
            // lblExistingUserName
            // 
            this.lblExistingUserName.AutoSize = true;
            this.lblExistingUserName.Location = new System.Drawing.Point(46, 191);
            this.lblExistingUserName.Name = "lblExistingUserName";
            this.lblExistingUserName.Size = new System.Drawing.Size(92, 20);
            this.lblExistingUserName.TabIndex = 3;
            this.lblExistingUserName.Text = "Existing User:";
            // 
            // lblExistingPassword
            // 
            this.lblExistingPassword.AutoSize = true;
            this.lblExistingPassword.Location = new System.Drawing.Point(75, 241);
            this.lblExistingPassword.Name = "lblExistingPassword";
            this.lblExistingPassword.Size = new System.Drawing.Size(72, 20);
            this.lblExistingPassword.TabIndex = 4;
            this.lblExistingPassword.Text = "Password:";
            // 
            // txtExistingUserName
            // 
            this.txtExistingUserName.Location = new System.Drawing.Point(153, 191);
            this.txtExistingUserName.Name = "txtExistingUserName";
            this.txtExistingUserName.Size = new System.Drawing.Size(275, 26);
            this.txtExistingUserName.TabIndex = 5;
            // 
            // txtExistingPassword
            // 
            this.txtExistingPassword.Location = new System.Drawing.Point(153, 235);
            this.txtExistingPassword.Name = "txtExistingPassword";
            this.txtExistingPassword.Size = new System.Drawing.Size(275, 26);
            this.txtExistingPassword.TabIndex = 6;
            // 
            // lblUserNotFound
            // 
            this.lblUserNotFound.AutoSize = true;
            this.lblUserNotFound.Location = new System.Drawing.Point(171, 310);
            this.lblUserNotFound.Name = "lblUserNotFound";
            this.lblUserNotFound.Size = new System.Drawing.Size(103, 20);
            this.lblUserNotFound.TabIndex = 7;
            this.lblUserNotFound.Text = "User Not Found";
            // 
            // btnLogOn
            // 
            this.btnLogOn.Location = new System.Drawing.Point(163, 354);
            this.btnLogOn.Name = "btnLogOn";
            this.btnLogOn.Size = new System.Drawing.Size(93, 39);
            this.btnLogOn.TabIndex = 9;
            this.btnLogOn.Text = "Log On";
            this.btnLogOn.UseVisualStyleBackColor = true;
            this.btnLogOn.Click += new System.EventHandler(this.btnLogOn_Click);
            // 
            // lblNewUsers
            // 
            this.lblNewUsers.AutoSize = true;
            this.lblNewUsers.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblNewUsers.Location = new System.Drawing.Point(163, 442);
            this.lblNewUsers.Name = "lblNewUsers";
            this.lblNewUsers.Size = new System.Drawing.Size(98, 25);
            this.lblNewUsers.TabIndex = 10;
            this.lblNewUsers.Text = "New Users";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button1.Location = new System.Drawing.Point(153, 470);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 28);
            this.button1.TabIndex = 11;
            this.button1.Text = "Register Now";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button2.Location = new System.Drawing.Point(12, 575);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(90, 28);
            this.button2.TabIndex = 12;
            this.button2.Text = "Rules";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(353, 354);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 13;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // frmPlayerLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(496, 615);
            this.ControlBox = false;
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblNewUsers);
            this.Controls.Add(this.btnLogOn);
            this.Controls.Add(this.lblUserNotFound);
            this.Controls.Add(this.txtExistingPassword);
            this.Controls.Add(this.txtExistingUserName);
            this.Controls.Add(this.lblExistingPassword);
            this.Controls.Add(this.lblExistingUserName);
            this.Controls.Add(this.lblExistingUser);
            this.Controls.Add(this.lblInstructionB);
            this.Controls.Add(this.lblInstructionA);
            this.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "frmPlayerLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login Screen";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInstructionA;
        private System.Windows.Forms.Label lblInstructionB;
        private System.Windows.Forms.Label lblExistingUser;
        private System.Windows.Forms.Label lblExistingUserName;
        private System.Windows.Forms.Label lblExistingPassword;
        private System.Windows.Forms.TextBox txtExistingUserName;
        private System.Windows.Forms.TextBox txtExistingPassword;
        private System.Windows.Forms.Label lblUserNotFound;
        private System.Windows.Forms.Button btnLogOn;
        private System.Windows.Forms.Label lblNewUsers;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}