﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz1318
{
    public partial class frmQ4n8 : Form
    {
        public frmQ4n8()
        {
            InitializeComponent();
        }
    }
}
