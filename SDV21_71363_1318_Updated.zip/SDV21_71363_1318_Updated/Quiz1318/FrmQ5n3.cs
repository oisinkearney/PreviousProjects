﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz1318
{
    public partial class FrmQ5n3 : Form
    {
        public FrmQ5n3()
        {
            InitializeComponent();
        }
    }
}
