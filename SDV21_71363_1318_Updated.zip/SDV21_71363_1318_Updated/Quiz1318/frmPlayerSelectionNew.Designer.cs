﻿
namespace Quiz1318
{
    partial class frmPlayerSelectionNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPlayerSelectionNew));
            this.lblPlayerDetails = new System.Windows.Forms.Label();
            this.lblPlayerName = new System.Windows.Forms.Label();
            this.lblPlayerPassword = new System.Windows.Forms.Label();
            this.txtPlayerPassword = new System.Windows.Forms.TextBox();
            this.txtPlayerName = new System.Windows.Forms.TextBox();
            this.pctPlayerIconChoosen = new System.Windows.Forms.PictureBox();
            this.lblChooseYourPlayer = new System.Windows.Forms.Label();
            this.lblDateOfQuiz = new System.Windows.Forms.Label();
            this.grpPlayerIcons = new System.Windows.Forms.GroupBox();
            this.pctPlayerIcon3 = new System.Windows.Forms.PictureBox();
            this.pctPlayerIcon2 = new System.Windows.Forms.PictureBox();
            this.pctPlayerIcon1 = new System.Windows.Forms.PictureBox();
            this.btnSaveDetails = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pctPlayerIconChoosen)).BeginInit();
            this.grpPlayerIcons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctPlayerIcon3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctPlayerIcon2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctPlayerIcon1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPlayerDetails
            // 
            this.lblPlayerDetails.AutoSize = true;
            this.lblPlayerDetails.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblPlayerDetails.Location = new System.Drawing.Point(126, 9);
            this.lblPlayerDetails.Name = "lblPlayerDetails";
            this.lblPlayerDetails.Size = new System.Drawing.Size(132, 29);
            this.lblPlayerDetails.TabIndex = 0;
            this.lblPlayerDetails.Text = "Player Details";
            // 
            // lblPlayerName
            // 
            this.lblPlayerName.AutoSize = true;
            this.lblPlayerName.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblPlayerName.Location = new System.Drawing.Point(41, 85);
            this.lblPlayerName.Name = "lblPlayerName";
            this.lblPlayerName.Size = new System.Drawing.Size(112, 20);
            this.lblPlayerName.TabIndex = 1;
            this.lblPlayerName.Text = "Enter player name:";
            // 
            // lblPlayerPassword
            // 
            this.lblPlayerPassword.AutoSize = true;
            this.lblPlayerPassword.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblPlayerPassword.Location = new System.Drawing.Point(47, 135);
            this.lblPlayerPassword.Name = "lblPlayerPassword";
            this.lblPlayerPassword.Size = new System.Drawing.Size(101, 20);
            this.lblPlayerPassword.TabIndex = 2;
            this.lblPlayerPassword.Text = " Enter Password:";
            // 
            // txtPlayerPassword
            // 
            this.txtPlayerPassword.Location = new System.Drawing.Point(154, 132);
            this.txtPlayerPassword.Name = "txtPlayerPassword";
            this.txtPlayerPassword.Size = new System.Drawing.Size(251, 23);
            this.txtPlayerPassword.TabIndex = 4;
            // 
            // txtPlayerName
            // 
            this.txtPlayerName.Location = new System.Drawing.Point(154, 82);
            this.txtPlayerName.Name = "txtPlayerName";
            this.txtPlayerName.Size = new System.Drawing.Size(251, 23);
            this.txtPlayerName.TabIndex = 5;
            // 
            // pctPlayerIconChoosen
            // 
            this.pctPlayerIconChoosen.BackColor = System.Drawing.Color.Turquoise;
            this.pctPlayerIconChoosen.Location = new System.Drawing.Point(167, 188);
            this.pctPlayerIconChoosen.Name = "pctPlayerIconChoosen";
            this.pctPlayerIconChoosen.Size = new System.Drawing.Size(100, 75);
            this.pctPlayerIconChoosen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctPlayerIconChoosen.TabIndex = 7;
            this.pctPlayerIconChoosen.TabStop = false;
            this.pctPlayerIconChoosen.DragDrop += new System.Windows.Forms.DragEventHandler(this.pctPlayerIconChoosen_DragDrop);
            this.pctPlayerIconChoosen.DragEnter += new System.Windows.Forms.DragEventHandler(this.pctPlayerIconChoosen_DragEnter);
            // 
            // lblChooseYourPlayer
            // 
            this.lblChooseYourPlayer.AutoSize = true;
            this.lblChooseYourPlayer.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblChooseYourPlayer.Location = new System.Drawing.Point(31, 188);
            this.lblChooseYourPlayer.Name = "lblChooseYourPlayer";
            this.lblChooseYourPlayer.Size = new System.Drawing.Size(117, 20);
            this.lblChooseYourPlayer.TabIndex = 8;
            this.lblChooseYourPlayer.Text = "Choose your player:";
            // 
            // lblDateOfQuiz
            // 
            this.lblDateOfQuiz.AutoSize = true;
            this.lblDateOfQuiz.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblDateOfQuiz.Location = new System.Drawing.Point(301, 188);
            this.lblDateOfQuiz.Name = "lblDateOfQuiz";
            this.lblDateOfQuiz.Size = new System.Drawing.Size(104, 20);
            this.lblDateOfQuiz.TabIndex = 9;
            this.lblDateOfQuiz.Text = "Date will appear";
            // 
            // grpPlayerIcons
            // 
            this.grpPlayerIcons.Controls.Add(this.pctPlayerIcon3);
            this.grpPlayerIcons.Controls.Add(this.pctPlayerIcon2);
            this.grpPlayerIcons.Controls.Add(this.pctPlayerIcon1);
            this.grpPlayerIcons.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.grpPlayerIcons.Location = new System.Drawing.Point(47, 279);
            this.grpPlayerIcons.Name = "grpPlayerIcons";
            this.grpPlayerIcons.Size = new System.Drawing.Size(358, 143);
            this.grpPlayerIcons.TabIndex = 10;
            this.grpPlayerIcons.TabStop = false;
            this.grpPlayerIcons.Text = "Player icons - Choose one( Drag it to the Red Box above)";
            // 
            // pctPlayerIcon3
            // 
            this.pctPlayerIcon3.Image = ((System.Drawing.Image)(resources.GetObject("pctPlayerIcon3.Image")));
            this.pctPlayerIcon3.Location = new System.Drawing.Point(236, 40);
            this.pctPlayerIcon3.Name = "pctPlayerIcon3";
            this.pctPlayerIcon3.Size = new System.Drawing.Size(100, 75);
            this.pctPlayerIcon3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctPlayerIcon3.TabIndex = 2;
            this.pctPlayerIcon3.TabStop = false;
            this.pctPlayerIcon3.DragOver += new System.Windows.Forms.DragEventHandler(this.pctPlayerIconChoosen_DragDrop);
            this.pctPlayerIcon3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pctPlayerIcon3_MouseDown);
            // 
            // pctPlayerIcon2
            // 
            this.pctPlayerIcon2.Image = ((System.Drawing.Image)(resources.GetObject("pctPlayerIcon2.Image")));
            this.pctPlayerIcon2.Location = new System.Drawing.Point(120, 40);
            this.pctPlayerIcon2.Name = "pctPlayerIcon2";
            this.pctPlayerIcon2.Size = new System.Drawing.Size(100, 75);
            this.pctPlayerIcon2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctPlayerIcon2.TabIndex = 1;
            this.pctPlayerIcon2.TabStop = false;
            this.pctPlayerIcon2.DragOver += new System.Windows.Forms.DragEventHandler(this.pctPlayerIconChoosen_DragDrop);
            this.pctPlayerIcon2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pctPlayerIcon2_MouseDown);
            // 
            // pctPlayerIcon1
            // 
            this.pctPlayerIcon1.Image = ((System.Drawing.Image)(resources.GetObject("pctPlayerIcon1.Image")));
            this.pctPlayerIcon1.Location = new System.Drawing.Point(6, 40);
            this.pctPlayerIcon1.Name = "pctPlayerIcon1";
            this.pctPlayerIcon1.Size = new System.Drawing.Size(100, 75);
            this.pctPlayerIcon1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pctPlayerIcon1.TabIndex = 0;
            this.pctPlayerIcon1.TabStop = false;
            this.pctPlayerIcon1.DragOver += new System.Windows.Forms.DragEventHandler(this.pctPlayerIconChoosen_DragDrop);
            this.pctPlayerIcon1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pctPlayerIcon1_MouseDown);
            // 
            // btnSaveDetails
            // 
            this.btnSaveDetails.Location = new System.Drawing.Point(167, 428);
            this.btnSaveDetails.Name = "btnSaveDetails";
            this.btnSaveDetails.Size = new System.Drawing.Size(100, 23);
            this.btnSaveDetails.TabIndex = 3;
            this.btnSaveDetails.Text = "Save Details";
            this.btnSaveDetails.UseVisualStyleBackColor = true;
            this.btnSaveDetails.Click += new System.EventHandler(this.btnNextScreenRules_Click);
            // 
            // frmPlayerSelectionNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 461);
            this.ControlBox = false;
            this.Controls.Add(this.btnSaveDetails);
            this.Controls.Add(this.grpPlayerIcons);
            this.Controls.Add(this.lblDateOfQuiz);
            this.Controls.Add(this.lblChooseYourPlayer);
            this.Controls.Add(this.pctPlayerIconChoosen);
            this.Controls.Add(this.txtPlayerName);
            this.Controls.Add(this.txtPlayerPassword);
            this.Controls.Add(this.lblPlayerPassword);
            this.Controls.Add(this.lblPlayerName);
            this.Controls.Add(this.lblPlayerDetails);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Name = "frmPlayerSelectionNew";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "New Player Details";
            this.Load += new System.EventHandler(this.frmPlayerSelectionNew_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pctPlayerIconChoosen)).EndInit();
            this.grpPlayerIcons.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pctPlayerIcon3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctPlayerIcon2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctPlayerIcon1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPlayerDetails;
        private System.Windows.Forms.Label lblPlayerName;
        private System.Windows.Forms.Label lblPlayerPassword;
        private System.Windows.Forms.TextBox txtPlayerPassword;
        private System.Windows.Forms.TextBox txtPlayerName;
        private System.Windows.Forms.PictureBox pctPlayerIconChoosen;
        private System.Windows.Forms.Label lblChooseYourPlayer;
        private System.Windows.Forms.Label lblDateOfQuiz;
        private System.Windows.Forms.GroupBox grpPlayerIcons;
        private System.Windows.Forms.PictureBox pctPlayerIcon3;
        private System.Windows.Forms.PictureBox pctPlayerIcon2;
        private System.Windows.Forms.PictureBox pctPlayerIcon1;
        private System.Windows.Forms.Button btnSaveDetails;
    }
}