﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Quiz1318
{
    public partial class frmPlayerLogin : Form
    {

        public frmPlayerLogin()
        {
            InitializeComponent();
        }

        
        private void btnLogOn_Click(object sender, EventArgs e)
        {
            string userName = txtExistingUserName.Text.ToString();
            string userPassword = txtExistingPassword.Text.ToString();
            bool bUserFound = false;
            lblUserNotFound.Visible = false;

            string filePath = "../../TextFiles/txtScores.txt";
            string[] fileLinesToRead = File.ReadAllLines(filePath);

            for (int i = 0; i < fileLinesToRead.Count(); i = i+7)
            {
                for(int y = i; y< i + 7; y++)
                {
                    if (fileLinesToRead[y].Contains(userName))
                    {
                        if (fileLinesToRead[y + 1].Contains(userPassword))

                        {
                            bUserFound = true;
                        }
                    }
                }
            }
            if (bUserFound)
            {

                frmQuestion1 nextScreen = new frmQuestion1();
                nextScreen.Show();
                this.Close();

            }

        }

        
        private void button3_Click(object sender, EventArgs e)
        {
            frmQuestion1 nextScreen = new frmQuestion1();
            nextScreen.Show();
            this.Hide();
        }
    }
}

  
