﻿
namespace Quiz1318
{
    partial class frmDescriptionRules
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRule1 = new System.Windows.Forms.Label();
            this.lblRuleOne = new System.Windows.Forms.Label();
            this.lblRule2 = new System.Windows.Forms.Label();
            this.lblRuleTwo = new System.Windows.Forms.Label();
            this.lblRule3 = new System.Windows.Forms.Label();
            this.lblRulesThree = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAcceptRules = new System.Windows.Forms.Button();
            this.lblAcceptRules = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblRule1
            // 
            this.lblRule1.AutoSize = true;
            this.lblRule1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRule1.Location = new System.Drawing.Point(12, 29);
            this.lblRule1.Name = "lblRule1";
            this.lblRule1.Size = new System.Drawing.Size(57, 21);
            this.lblRule1.TabIndex = 0;
            this.lblRule1.Text = "Rule 1:";
            // 
            // lblRuleOne
            // 
            this.lblRuleOne.AutoSize = true;
            this.lblRuleOne.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRuleOne.Location = new System.Drawing.Point(12, 68);
            this.lblRuleOne.Name = "lblRuleOne";
            this.lblRuleOne.Size = new System.Drawing.Size(373, 23);
            this.lblRuleOne.TabIndex = 1;
            this.lblRuleOne.Text = "Please Answer all questions to the best of your ability.";
            // 
            // lblRule2
            // 
            this.lblRule2.AutoSize = true;
            this.lblRule2.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRule2.Location = new System.Drawing.Point(12, 111);
            this.lblRule2.Name = "lblRule2";
            this.lblRule2.Size = new System.Drawing.Size(51, 20);
            this.lblRule2.TabIndex = 2;
            this.lblRule2.Text = "Rule 2:";
            // 
            // lblRuleTwo
            // 
            this.lblRuleTwo.AutoSize = true;
            this.lblRuleTwo.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRuleTwo.Location = new System.Drawing.Point(12, 140);
            this.lblRuleTwo.Name = "lblRuleTwo";
            this.lblRuleTwo.Size = new System.Drawing.Size(154, 23);
            this.lblRuleTwo.TabIndex = 3;
            this.lblRuleTwo.Text = "Attempt all questions.";
            // 
            // lblRule3
            // 
            this.lblRule3.AutoSize = true;
            this.lblRule3.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRule3.Location = new System.Drawing.Point(12, 175);
            this.lblRule3.Name = "lblRule3";
            this.lblRule3.Size = new System.Drawing.Size(51, 20);
            this.lblRule3.TabIndex = 4;
            this.lblRule3.Text = "Rule 3:";
            // 
            // lblRulesThree
            // 
            this.lblRulesThree.AutoSize = true;
            this.lblRulesThree.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblRulesThree.Location = new System.Drawing.Point(12, 211);
            this.lblRulesThree.Name = "lblRulesThree";
            this.lblRulesThree.Size = new System.Drawing.Size(110, 23);
            this.lblRulesThree.TabIndex = 5;
            this.lblRulesThree.Text = "Enjoy the quiz.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 276);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 15);
            this.label1.TabIndex = 6;
            // 
            // btnAcceptRules
            // 
            this.btnAcceptRules.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnAcceptRules.Location = new System.Drawing.Point(365, 391);
            this.btnAcceptRules.Name = "btnAcceptRules";
            this.btnAcceptRules.Size = new System.Drawing.Size(75, 23);
            this.btnAcceptRules.TabIndex = 7;
            this.btnAcceptRules.Text = "Login Page";
            this.btnAcceptRules.UseVisualStyleBackColor = true;
            this.btnAcceptRules.Click += new System.EventHandler(this.btnAcceptRules_Click);
            // 
            // lblAcceptRules
            // 
            this.lblAcceptRules.AutoSize = true;
            this.lblAcceptRules.Font = new System.Drawing.Font("Arial Narrow", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblAcceptRules.Location = new System.Drawing.Point(329, 348);
            this.lblAcceptRules.Name = "lblAcceptRules";
            this.lblAcceptRules.Size = new System.Drawing.Size(158, 23);
            this.lblAcceptRules.TabIndex = 8;
            this.lblAcceptRules.Text = "Accept and Continue:";
            // 
            // frmDescriptionRules
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblAcceptRules);
            this.Controls.Add(this.btnAcceptRules);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblRulesThree);
            this.Controls.Add(this.lblRule3);
            this.Controls.Add(this.lblRuleTwo);
            this.Controls.Add(this.lblRule2);
            this.Controls.Add(this.lblRuleOne);
            this.Controls.Add(this.lblRule1);
            this.Name = "frmDescriptionRules";
            this.Text = "frmDescriptionRules";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblRule1;
        private System.Windows.Forms.Label lblRuleOne;
        private System.Windows.Forms.Label lblRule2;
        private System.Windows.Forms.Label lblRuleTwo;
        private System.Windows.Forms.Label lblRule3;
        private System.Windows.Forms.Label lblRulesThree;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAcceptRules;
        private System.Windows.Forms.Label lblAcceptRules;
    }
}